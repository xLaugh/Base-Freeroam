fx_version 'cerulean'
game 'gta5'

-- Lua 5.4
lua54 'yes'

client_scripts {
  'config.lua',
  "client/*.lua",
  'configserver.lua',
}

server_scripts {
  "@oxmysql/lib/MySQL.lua",
  'config.lua',
  "server/*.lua",
}

shared_script '@es_extended/imports.lua'