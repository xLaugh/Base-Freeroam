Death = Death or {}

if GetCurrentResourceName() ~= "entrepot_core" then return end

RegisterServerEvent("cDeath:RevivePlayerId")
AddEventHandler("cDeath:RevivePlayerId", function(player)
    TriggerClientEvent("cDeath:RevivePlayerId", player)
end)