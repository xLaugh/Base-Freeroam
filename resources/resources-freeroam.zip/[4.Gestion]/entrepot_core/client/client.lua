--Suppression Nord
Citizen.CreateThread(function()
    while true do
    Citizen.Wait(0)
  SetBlipAlpha(GetNorthRadarBlip(), 0)
 end
end)

-- Désactiver les sons ambiants - Scanner Police, Bruits de tir à l'ammunation
Citizen.CreateThread(function()
    StartAudioScene('CHARACTER_CHANGE_IN_SKY_SCENE')
    SetAudioFlag("PoliceScannerDisabled", true)
end)

-- Désactiver le bruit du dispatch de la Police
Citizen.CreateThread(function()
    while true do
        Wait(500)
        for i = 1, 12 do
            EnableDispatchService(i, false)
        end
        SetPlayerWantedLevel(PlayerId(), 0, false)
        SetPlayerWantedLevelNow(PlayerId(), false)
        SetPlayerWantedLevelNoDrop(PlayerId(), 0, false)
    end
end)

--Désactiver HUD Argent
Citizen.CreateThread(function()
    while true do
        Citizen.Wait(0)
        HideHudComponentThisFrame(3)
        HideHudComponentThisFrame(4)
        HideHudComponentThisFrame(13)
    end
end)

--Activer train
Citizen.CreateThread(function()
SwitchTrainTrack(0, true)
SwitchTrainTrack(3, true)
N_0x21973bbf8d17edfa(0, 120000)
SetRandomTrains(true)
end)

AddEventHandler("playerSpawned", function()
  Citizen.CreateThread(function()

    local player = PlayerId()
    local playerPed = GetPlayerPed(-1)

    -- Enable pvp
    NetworkSetFriendlyFireOption(true)
    SetCanAttackFriendly(playerPed, true, true)

  end)
end)