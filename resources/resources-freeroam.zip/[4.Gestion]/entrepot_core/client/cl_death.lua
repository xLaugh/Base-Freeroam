Death = Death or {}

if GetCurrentResourceName() ~= "entrepot_core" then return end

local function GetPlayerByEntityID(id)
    for i = 0, 255 do
        if (NetworkIsPlayerActive(i) and GetPlayerPed(i) == id) then
            return i
        end
    end
    return nil
end

function Death:TableGetValue(Y,Z,n)
    if not Y or not Z or type(Y)~="table"then 
        return 
    end
    for O,y in pairs(Y)do 
        if n and y[n]==Z or y==Z then 
            return true,O 
        end 
    end 
end

function Death:Revive()
    local pPed = PlayerPedId()
    local coords = GetEntityCoords(pPed)
    NetworkResurrectLocalPlayer(coords, GetEntityHeading(pPed), true, true, false)
    SetTimeout(100, function()
        local pPed2 = GetPlayerPed(-1)
        if pPed ~= pPed2 then
            DeleteEntity(pPed)
        end
    end)
end

function Death:DrawTextScreen(Text,Text3,Taille,Text2,Font,Justi,havetext) -- Créer un text 2D a l'écran
    SetTextFont(Font)
    SetTextScale(Taille, Taille)
    SetTextColour(255, 255, 255, 255)
    SetTextJustification(Justi or 1)
    SetTextEntry("STRING")
    if havetext then 
        SetTextWrap(Text, Text + 0.1)
    end
    AddTextComponentString(Text2)
    DrawText(Text, Text3)
end

function Death:DrawCenterText(msg, time)
	ClearPrints()
	SetTextEntry_2("jamyfafi")
	AddTextComponentString(msg)
	DrawSubtitleTimed(time and math.ceil(time) or 0, true)
end

function Death:TeleportCoords(vector, peds)
	if not vector or not peds then return end
	local x, y, z = vector.x, vector.y, vector.z + 0.98
	peds = peds or PlayerPedId()

	RequestCollisionAtCoord(x, y, z)
	NewLoadSceneStart(x, y, z, x, y, z, 50.0, 0)

	local TimerToGetGround = GetGameTimer()
	while not IsNewLoadSceneLoaded() do
		if GetGameTimer() - TimerToGetGround > 3500 then
			break
		end
		Citizen.Wait(0)
	end

	SetEntityCoordsNoOffset(peds, x, y, z)

	TimerToGetGround = GetGameTimer()
	while not HasCollisionLoadedAroundEntity(peds) do
		if GetGameTimer() - TimerToGetGround > 3500 then
			break
		end
		Citizen.Wait(0)
	end

	local retval, GroundPosZ = GetGroundZCoordWithOffsets(x, y, z)
	TimerToGetGround = GetGameTimer()
	while not retval do
		z = z + 5.0
		retval, GroundPosZ = GetGroundZCoordWithOffsets(x, y, z)
		Wait(0)

		if GetGameTimer() - TimerToGetGround > 3500 then
			break
		end
	end

	SetEntityCoordsNoOffset(peds, x, y, retval and GroundPosZ or z)
	NewLoadSceneStop()
	return true
end

-- Effects
function Death:CreateEffect(style, default, time) -- Créer un effet
    Citizen.CreateThread(function()
        DoScreenFadeOut(1000)
        Citizen.Wait(1000)
        SetTimecycleModifier(style or "spectator3")
        if default then 
            SetCamEffect(2)
        end
        DoScreenFadeIn(1000)
        Citizen.Wait(time or 5000)
        local pPed = GetPlayerPed(-1)
        DoScreenFadeOut(1000)
        Citizen.Wait(1000)
        DoScreenFadeIn(1000)
        ClearTimecycleModifier()
        ResetScenarioTypesEnabled()
		SetCamEffect(0)
    end)
end

function Death:GetAllCauseOfDeath(ped)
    local exist, lastBone = GetPedLastDamageBone(ped)
    local cause, what, timeDeath = GetPedCauseOfDeath(ped), Citizen.InvokeNative(0x93C8B64DEB84728C, ped), Citizen.InvokeNative(0x1E98817B311AE98A, ped)
    if what and DoesEntityExist(what) then
        if IsEntityAPed(what) then
            what = "Traces de combat"
        elseif IsEntityAVehicle(what) then
            what = "Écrasé par un véhicule"
        elseif IsEntityAnObject(what) then
            what = "Semble s'être pris un objet"
        end
    end
    what = type(what) == "string" and what or "Inconnue"

    if cause then
        if IsWeaponValid(cause) then
            cause = Death.weaponHashType[GetWeaponDamageType(cause)] or "Inconnue"
        elseif IsModelInCdimage(cause) then
            cause = "Véhicule"
        end
    end
    cause = type(cause) == "string" and cause or "Mêlée"

    local boneName = "Dos"
    if exist and lastBone then
        for k, v in pairs(Death.boneTypes) do
            if Death:TableGetValue(v, lastBone) then
                boneName = k
                break
            end
        end
    end

    return timeDeath, what, cause, boneName
end

function Death:RequestAndWaitDict(dict)
    RequestAnimDict(dict)
    while not HasAnimDictLoaded(dict) do 
        Wait(50)
    end
end

function ThinkDeath(player)
    -- Texte à l'écran pour le joueur
    Death:DrawTextScreen(0.16, 0.91, 0.4, "Origine: ~b~" .. (Death.deathCause[2] or "Inconnue"), 4)
    Death:DrawTextScreen(0.16, 0.93, 0.4, "Cause: ~b~" .. (Death.deathCause[3] or "Inconnue"), 4)
    Death:DrawTextScreen(0.16, 0.96, 0.4, "Blessure: ~b~" .. (Death.deathCause[4] or "Inconnu"), 4)

    if Death.PlayerDead then
        Death.PlayerKO = false 
        SetPedToRagdoll(player, 1000, 1000, 0, 0, 0, 0)
        if GetGameTimer() >= Death.deathTime and Death.PlayerDead then
            SetTimecycleModifier("damage")
            Death:DrawCenterText('Appuyez sur ~b~Y~s~ pour se relever', 500)
            if IsControlJustPressed(1, 246) then 
                local pPed = player
                Death.PlayerDead = false 
                DoScreenFadeOut(1000)
                Wait(1000)
                -- Ne pas téléporter le joueur, ou utiliser une fonction qui ne change pas la position
                -- Death:TeleportCoords(Death.RespawnPos, pPed) -- Commenter ou enlever cette ligne
                -- Nouvelle ligne ajoutée pour maintenir le joueur à sa position actuelle
                SetEntityCoords(pPed, GetEntityCoords(pPed), true, true, true, false)
                Wait(500)
                DoScreenFadeIn(1000)
                ClearPedBloodDamage(pPed)
                PlaySoundFrontend(-1, "1st_Person_Transition", "PLAYER_SWITCH_CUSTOM_SOUNDSET", 0)
                Citizen.Wait(10)
                ClearPedTasksImmediately(pPed)
                Death.HasRespawn = true 
                Death.HasRespawnTimer = GetGameTimer() or 0
                Death:CreateEffect("damage", true, 5000)
                SetEntityHealth(pPed, 120)
                PlaySoundFrontend(-1, "1st_Person_Transition", "PLAYER_SWITCH_CUSTOM_SOUNDSET", 0)
                Citizen.Wait(300)
            end
        else
            -- Gestion de l'état de mort du joueur
            ShakeGameplayCam("DEATH_FAIL_IN_EFFECT_SHAKE", 1.0)
            SetTimecycleModifier("damage")
            while GetGameTimer() <= Death.deathTime and Death.PlayerDead do
                Death:DrawTextScreen(0.16, 0.91, 0.4, "Origine: ~b~" .. (Death.deathCause[2] or "Inconnue"), 4)
                Death:DrawTextScreen(0.16, 0.93, 0.4, "Cause: ~b~" .. (Death.deathCause[3] or "Inconnue"), 4)
                Death:DrawTextScreen(0.16, 0.96, 0.4, "Blessure: ~b~" .. (Death.deathCause[4] or "Inconnu"), 4)
                Death:DrawTextScreen(0.85, 0.82, 0.8, "Il vous reste ~b~"..math.floor((Death.deathTime - GetGameTimer()) / 1000).." ~s~secondes.", 4, 0)
                SetPedToRagdoll(player, 1000, 1000, 0, 0, 0, 0)
                Citizen.Wait(0)
            end
            DoScreenFadeOut(1000)
            Citizen.Wait(1000)
            ClearTimecycleModifier()
            DoScreenFadeIn(1000)
        end
    elseif Death.PlayerKO then 
        Death.PlayerDead = false 
        SetPedToRagdoll(player, 1000, 1000, 0, 0, 0, 0)
        if GetGameTimer() >= Death.deathTime and Death.PlayerKO then
            SetTimecycleModifier("damage")
            Death:DrawCenterText('Appuyez sur ~b~Y~s~ pour vous relever.', 5000)
            if IsControlJustPressed(1, 246) then 
                Death:RequestAndWaitDict('mini@cpr@char_b@cpr_str')
                Death:RequestAndWaitDict('mini@cpr@char_b@cpr_def')
                local pPed = player
                Death.PlayerKO = false 
                DoScreenFadeOut(1000)
                Wait(1000)
                DoScreenFadeIn(1000)
                ClearPedBloodDamage(pPed)
                SetEntityHealth(pPed, 120)
                TaskPlayAnim(pPed, 'mini@cpr@char_b@cpr_def', 'cpr_intro', 8.0, 8.0, -1, 0, 0, false, false, false)
                Citizen.Wait(5200)
                TaskPlayAnim(pPed, 'mini@cpr@char_b@cpr_str', 'cpr_success', 8.0, 8.0, 30590, 0, 0, false, false, false)    
                Citizen.Wait(30590)
                PlaySoundFrontend(-1, "1st_Person_Transition", "PLAYER_SWITCH_CUSTOM_SOUNDSET", 0)
                Citizen.Wait(10)
                ClearPedTasks(pPed)
                if Death.tranch then 
                    Death.HasRespawn = true 
                    Death.HasRespawnTimer = GetGameTimer() or 0
                end
                Death:CreateEffect("damage", true, Death.tranch and 20000 or 35000)
                PlaySoundFrontend(-1, "1st_Person_Transition", "PLAYER_SWITCH_CUSTOM_SOUNDSET", 0)
                Citizen.Wait(300)
                ESX.ShowNotification("~b~KO\n~w~Vous venez de vous relever.")
            end
        else
            -- Gestion de l'état KO du joueur
            ShakeGameplayCam("DEATH_FAIL_IN_EFFECT_SHAKE", 1.0)
            SetTimecycleModifier("damage")
            while GetGameTimer() <= Death.deathTime and Death.PlayerKO do
                Death:DrawTextScreen(0.16, 0.91, 0.4, "Origine: ~b~" .. (Death.deathCause[2] or "Inconnue"), 4)
                Death:DrawTextScreen(0.16, 0.93, 0.4, "Cause: ~b~" .. (Death.deathCause[3] or "Inconnue"), 4)
                Death:DrawTextScreen(0.16, 0.96, 0.4, "Blessure: ~b~" .. (Death.deathCause[4] or "Inconnu"), 4)
                Death:DrawTextScreen(0.85, 0.82, 0.8, "Il vous reste ~b~"..math.floor((Death.deathTime - GetGameTimer()) / 1000).." ~s~secondes.", 4, 0)
                SetPedToRagdoll(player, 1000, 1000, 0, 0, 0, 0)
                Citizen.Wait(0)
            end
            DoScreenFadeOut(1000)
            Citizen.Wait(1000)
            ClearTimecycleModifier()
            DoScreenFadeIn(1000)
        end
    end
end

AddEventHandler('cDeath:onPlayerDied', function(victimEntity, attackEntity)
    local player = PlayerPedId()
    local pPed = player
    local pPos = GetEntityCoords(player)
    if victimEntity and not Death.PlayerDead and not Death.PlayerKO and IsEntityDead(victimEntity) then
        Death.PlayerDead = true
        Death.Call = true 
        Death.deathCause = table.pack(Death:GetAllCauseOfDeath(pPed))
        Death.deathTime = GetGameTimer() + Death.waitTime
        Death.deathTime1 = GetGameTimer()
        Death:Revive()
        Death:CreateEffect("damage", true, Death.waitTime)
        SetPedToRagdollWithFall(pPed, 1500, 2000, 0, - GetEntityForwardVector(pPed), 1.0, 0.0, .0, .0, .0, .0, .0)
        SetTimecycleModifier("damage")
        Citizen.Wait(1000)
        SetPedToRagdollWithFall(pPed, 0, 0, 0, -GetEntityForwardVector(pPed), .0, 0.0, .0, .0, .0, .0, .0)

        Citizen.CreateThread(function()
            while Death.PlayerDead do 
                Wait(0)
                ThinkDeath(player)
            end
        end)
    end
end)

AddEventHandler('cDeath:onPlayerKilled', function(victimEntity, _z)
    local player = PlayerPedId()
    local pPed = player
    local pPos = GetEntityCoords(player)
    if not Death.PlayerDead and not Death.PlayerKO then
        Death.PlayerKO = true
        Death.PlayerDead = false 

        if Death:TableGetValue(Death.WeaponHashcontend, _z) then 
            Death.contend = true 
        elseif Death:TableGetValue(Death.WeaponHashtranch, _z) then 
            Death.tranch = true 
        end

        Death.deathCause = table.pack(Death:GetAllCauseOfDeath(pPed))
        Death.deathTime = GetGameTimer() + (Death.tranch and Death.waitTimeKo + 15000 or Death.waitTimeKo)
        Death.deathTime1 = GetGameTimer()

        ESX.ShowNotification("Vous êtes tombé ~b~KO~s~.")

        Death:Revive()
        Death:CreateEffect("damage", true, (Death.tranch and Death.waitTimeKo + 15000 or Death.waitTimeKo))
        SetPedToRagdollWithFall(pPed, 1500, 2000, 0, - GetEntityForwardVector(pPed), 1.0, 0.0, .0, .0, .0, .0, .0)
        SetTimecycleModifier("damage")
        Citizen.Wait(1000)
        SetPedToRagdollWithFall(pPed, 0, 0, 0, -GetEntityForwardVector(pPed), .0, 0.0, .0, .0, .0, .0, .0)

        Citizen.CreateThread(function()
            while Death.PlayerKO do 
                Wait(0)
                ThinkDeath(player)
            end
        end)
    end
end)


Citizen.CreateThread(function()
    while true do
        local pPed = PlayerPedId()
        local wait = 2000

        if IsEntityDead(pPed) then
            local pCause = GetPedSourceOfDeath(pPed)
            local Cause = GetPedCauseOfDeath(pPed)
            local KO = IsPedArmed(pCause, 1) or Death:TableGetValue(Death.AllWeaponKO, Cause)
            TriggerEvent(KO and "cDeath:onPlayerKilled" or "cDeath:onPlayerDied", pPed, Cause)
        end

        if Death.PlayerDead or Death.PlayerKO then 
            wait = 5
			SetEntityHealth(pPed, 101)
			SetPedToRagdoll(pPed, 1000, 1000, 0, 1, 1, 0)
			ResetPedRagdollTimer(pPed)
			NetworkSetLocalPlayerInvincibleTime(1000)
		end

        if Death.HasRespawn then 
            wait = 5
        
            Death.RespawnTime = Death.HasRespawnTimer + Death.RespawnTimeClean
            if Death.RespawnTime <= GetGameTimer() then 
                Death.HasRespawn = false 
                Death.RespawnTime = 0
                Death.HasRespawnTimer = 0
                ResetPedMovementClipset(pPed)
            end
        end

        Citizen.Wait(wait)
    end
end)

AddEventHandler("gameEventTriggered", function(eventName, eventArguments)
    if eventName == "CEventNetworkEntityDamage" then
        local victimEntity, attackEntity, _, fatalBool, weaponUsed, _a, _z, _e, _r, _t, entityType = table.unpack(eventArguments)
        local ped = PlayerPedId()

        if ped ~= victimEntity then
            return
        end

        local KO = _a ~= 0 and (IsPedArmed(attackEntity, 1) or Death:TableGetValue(Death.AllWeaponKO, _z))
        if not Death.PlayerDead and not Death.PlayerKO then 
            TriggerEvent(KO and "cDeath:onPlayerKilled" or _a ~= 0 and "cDeath:onPlayerDied" or "cDeath:EntityTakeDamage", victimEntity, attackEntity, _z)
        end
    end
end)

RegisterNetEvent('cDeath:RevivePlayerId')
AddEventHandler('cDeath:RevivePlayerId', function()
    local pPed = PlayerPedId()
    local pPos = GetEntityCoords(pPed)

    Death.PlayerDead = false
    Death.PlayerKO = false
    ClearPedBloodDamage(pPed)
    PlaySoundFrontend(-1, "1st_Person_Transition", "PLAYER_SWITCH_CUSTOM_SOUNDSET", 0)
    SetEntityHealth(pPed, 120)
    Wait(250)
    Death.Invincible = false
    TriggerEvent('playerSpawned', pPos.x, pPos.y, pPos.z)
    SetCurrentPedWeapon(pPed, GetHashKey('WEAPON_UNARMED'), true)

    Death:CreateEffect("damage", true, 15000)
    ClearPedTasks(pPed)
    ESX.ShowNotification("~b~Réanimation\n~w~Vous venez d\'être réanimé.")
end)